modified version of MPEGflow that output a .m file to be used in MATLAB

For compilation instructions refer to :
https://github.com/vadimkantorov/mpegflow