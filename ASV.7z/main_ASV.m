clear all
close all
clc

%load the test sequence file
load testes.mat

%adjust the path of the result tests folder
%%% IMPORTANT %%% change it according to your path
path = 'D:/doutorado/codigos/';

%adjust the path of the database
%%% IMPORTANT %%% change it according to your path
path2 = 'D:/doutorado/testes_dez/base/';

%adjust the path of the feature files
%%% IMPORTANT %%% change it according to your path
path3 = 'D:\doutorado\testes_dez\features\';

%%
for i =47
% type a(audio), v(video), c(audio+video)
type = struct_tests(i).type;

% For audio type only selects the Voice Activity detection. 
% VAD = 0 (no VAD) VAD=1 (with VAD)
VAD = struct_tests(i).VAD;

% For video or audio +video selects the Visual VAD. 
% VVAD = 0 (no VVAD) VVAD=1 (with VVAD)
VVAD = struct_tests(i).VVAD;

%For video type selects the zero removal
rz=struct_tests(i).rz;

% For audio type selects the SNR (30 = no noise)
snr = struct_tests(i).snr;

% para tipo �udio seleciona o tipo do ru�do
noise = struct_tests(i).noise;

% For video type select = y (only y matrix) select =x (matrices x e y)
select = struct_tests(i).select;

% For video type selects the number of coefficients. If select ='x' the
% number of coefficients is equal to double ncoef.
ncoef = struct_tests(i).ncoef;

delta=struct_tests(i).delta;

if type =='a'
    tipo = ['a','_VAD_',num2str(VAD),'_VVAD_',num2str(VVAD),'_SNR_',num2str(snr),'_ruido_',noise,'_matriz_','-','_coef_','-'];
end

if type =='v'
    tipo = ['v','_VAD_','-','_VVAD_',num2str(VVAD),'_SNR_','-','_ruido_','-','_matriz_',select,'_coef_',num2str(ncoef),'_rz_',num2str(rz),'_delta_',num2str(delta)];
end

if type =='c'
    tipo  = ['av','_VAD_','-','_VVAD_',num2str(VVAD),'_SNR_',num2str(snr),'_ruido_',noise,'_matriz_',select,'_coef_',num2str(ncoef),'_rz_',num2str(rz),'_delta_',num2str(delta)];
    tipoa = ['a','_VAD_',num2str(VAD),'_VVAD_',num2str(VVAD),'_SNR_',num2str(snr),'_ruido_',noise,'_matriz_','-','_coef_','-'];
    tipov = ['v','_VAD_','-','_VVAD_',num2str(VVAD),'_SNR_','-','_ruido_','-','_matriz_',select,'_coef_',num2str(ncoef),'_rz_',num2str(rz),'_delta_',num2str(delta)];
end

mkdir(tipo)


%% Extract the visual feature matrices of dimension frames x ncoef
if type=='v'
    final_feature = motionfeatures(ncoef,VVAD,select,rz,delta,path2);
    save([path,tipo,'\final_feature_',tipo],'final_feature');
end

%% write the HTK files
if type=='v'
    load([path,'\',tipo,'\final_feature_',tipo])
    htk_write(tipo,final_feature,snr,VAD,VVAD,noise,path2,path3)
end
if type=='c'
    load([path,tipov,'\final_feature_',tipov])
    final_feature_VVAD0 = final_feature;
    load ([path,tipoa,'\vetor_mfcc_',tipoa])
    final_feature2 = concat_features (final_feature, vetor_mfcc);
    save([path,tipo,'\final_feature_',tipo],'final_feature2');
    htk_write(tipo,final_feature2,snr,VAD,VVAD,noise)
end
if type=='a'
    final_feature=0;
    vetor_mfcc = htk_write(tipo,final_feature,snr,VAD,VVAD,noise)
    save([path,tipo,'\vetor_mfcc_',tipo],'vetor_mfcc');
end

%% create the lists
if type=='a'
    tipou = ['a','_VAD_','0','_VVAD_','0','_SNR_','30','_ruido_',noise,'_matriz_','-','_coef_','-'];
%     if VVAD==1
%         tipou = ['a','_VAD_','0','_VVAD_','1','_SNR_','30','_ruido_',noise,'_matriz_','-','_coef_','-'];
%     end
    create_lists(tipo,tipou,path,path3)
end
if type=='v'
    create_lists(tipo,tipo,path,path3)
end
if type=='c'
    tipou = ['av','_VAD_','-','_VVAD_','0','_SNR_','30','_ruido_',noise,'_matriz_',select,'_coef_',num2str(ncoef),'_rz_',num2str(rz),'_delta_',num2str(delta)];
%     if VVAD==1
%          tipou = ['av','_VAD_','-','_VVAD_','1','_SNR_','30','_ruido_',noise,'_matriz_',select,'_coef_',num2str(ncoef),'_rz_',num2str(rz),'_delta_',num2str(delta)];
%     end
    create_lists(tipo,tipou,path,path3)
end

%% Ivector tests
ivector(tipo,path,path3)
a=1
end