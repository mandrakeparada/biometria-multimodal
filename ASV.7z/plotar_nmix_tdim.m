load('D:/doutorado/testes_dez/resultados_final_dez_ivector_gmm64_t100/a_VAD_0_VVAD_0_SNR_10_ruido_b_matriz_-_coef_-/ivector_results__tvdim100_a_VAD_0_VVAD_0_SNR_10_ruido_b_matriz_-_coef_-')
compute_eer(scores4, labels2, true, false);
hold on
load('D:/doutorado/testes_dez/resultados_17_01_ivector_gmm128_t100/a_VAD_0_VVAD_0_SNR_10_ruido_b_matriz_-_coef_-/ivector_results__tvdim100_a_VAD_0_VVAD_0_SNR_10_ruido_b_matriz_-_coef_-')
compute_eer(scores4, labels2, true, false);
hold on
load('D:/doutorado/testes_dez/resultados_17_01_ivector_gmm256_t100/a_VAD_0_VVAD_0_SNR_10_ruido_b_matriz_-_coef_-/ivector_results__tvdim100_a_VAD_0_VVAD_0_SNR_10_ruido_b_matriz_-_coef_-')
compute_eer(scores4, labels2, true, false);
hold on
load('D:/doutorado/testes_dez/resultados_20_01_ivector_gmm128_t50/a_VAD_0_VVAD_0_SNR_10_ruido_b_matriz_-_coef_-/ivector_results__tvdim100_a_VAD_0_VVAD_0_SNR_10_ruido_b_matriz_-_coef_-')
compute_eer(scores4, labels2, true, false);
hold on
load('D:/doutorado/testes_dez/resultados_20_01_ivector_gmm128_t150/a_VAD_0_VVAD_0_SNR_10_ruido_b_matriz_-_coef_-/ivector_results__tvdim100_a_VAD_0_VVAD_0_SNR_10_ruido_b_matriz_-_coef_-')
compute_eer(scores4, labels2, true, false);
hold on
compute_eer_n(scores4, labels2, true, false);

legend({'\itC\rm = 64 \it  R\rm = 100', ...
    '\itC\rm = 128 \itR\rm = 100',...
    '\itC\rm = 256 \itR\rm = 100',...
    '\itC\rm = 128 \itR\rm = 50',...
    '\itC\rm = 128 \itR\rm = 150',...
    '\ity = x'},'Location','East')
ax = gca;
ax.FontSize=16;
ax.FontName='Times New Roman';