function [thresh,eer, dcf08, dcf10] = compute_eer_n(scores, labels, showfig, showfig2)
% calculates the equal error rate (EER) performance measure.
%
% Inputs:                      
%   - scores        : likelihood scores for target and non-target trials
%   - labels        : true labels for target and non-target trials, can be
%					  either binary (0's and 1's) or a cell array with 
%					  "target" and "impostor" string labels
%   - showfig       : if true the DET curve is displayed
%
% Outputs:
%   - eer           : percent equal error rate (EER)
%   - dcf08         : minimum detection cost function (DCF) with SRE'08
%                     parameters
%   - dcf10         : minimum DCF with SRE'10 parameters
%    
% thresh = [T_FAE;T_FRE;T_FRE_FAE]
%
% Omid Sadjadi <s.omid.sadjadi@gmail.com>
% Microsoft Research, Conversational Systems Research Center


if iscell(labels),
    labs = zeros(length(labels), 1);
    labs(ismember(labels, 'target')) = 1;
    labels = labs;
    clear labs;
end

[scores2,I] = sort(scores);
x = labels(I);

FR = cumsum( x == 1 ) / (sum( x == 1 ) + eps);
TR = cumsum( x == 0 ) / (sum( x == 0 ) + eps);
FA = 1 - TR;
TA = 1 - FR;

FRE = FR ./ ( TA + FR + eps );
FAE = FA ./ ( TR + FA + eps );
difs = FRE - FAE;
idx1 = find(difs< 0, 1, 'last');
idx2 = find(difs>= 0, 1 );
x = [FRE(idx1); FAE(idx1)];
y = [FRE(idx2); FAE(idx2)];
a = ( x(1) - x(2) ) / ( y(2) - x(2) - y(1) + x(1) );
eer = 100 * ( x(1) + a * ( y(1) - x(1) ) );

%FAE = FPR ; FRE = FNR ; FP = FA ; FN = FR
%%Lousiane protocol

difs2 = abs(difs);
min1 = find (FAE==0,1,'first');
T_FAE = scores2(min1); %Threshhold TFAE=0 ou TFRP = 0
%FA_FAE = FA(min1);
%FR_FAE = FR(min1);
%TER_FAE = FA_FAE + FR_FAE;

min2 = find (FRE==0,1,'last');%Threshhold TFRE=0 ou TFNR = 0
T_FRE = scores2(min2);
%FA_FRE = FA(min2);
%FR_FRE = FR(min2);
%TER_FRE = FA_FRE + FR_FRE;

[eer2,min3] = min(difs2);%Threshhold TFRE=FAE ou TFNR = FPR
T_FRE_FAE = scores2(min3);
%FA_FRE_FAE = FA(min3);
%FR_FRE_FAE = FR(min3);
%TER_FRE_FAE = FA_FRE_FAE + FR_FPR_FNR;

thresh = [T_FAE;T_FRE;T_FRE_FAE];

if ( nargout > 1 ),
    Cmiss = 10; Cfa = 1; P_tgt = 0.01; % SRE-2008 performance parameters
    Cdet  = Cmiss * FRE * P_tgt + Cfa * FAE * ( 1 - P_tgt);
%     Cdefault = min(Cmiss * P_tgt, Cfa * ( 1 - P_tgt));
    dcf08 = 100 * min(Cdet); % note this is not percent
end
if ( nargout >= 3),
    Cmiss = 1; Cfa = 1; P_tgt = 0.001; % SRE-2010 performance parameters
    Cdet  = Cmiss * FRE * P_tgt + Cfa * FAE * ( 1 - P_tgt);
%     Cdefault = min(Cmiss * P_tgt, Cfa * ( 1 - P_tgt));
    dcf10 = 100 * min(Cdet); % note this is not percent
end

if showfig
    
    plot_det(FAE, FRE)
end

if showfig2
    
    [hAx,hLine1,hLine2]= plotyy(scores2,FRE,scores2,FAE)
    title('FRE and FAE x scores')
    xlabel('scores')
    ylabel(hAx(1),'FRE') % left y-axis
    ylabel(hAx(2),'FAE') % right y-axis
end

function plot_det(FAE, FRE)
% plots the detection error tradeoff (DET) curve

fnr = icdf(FRE);
fpr = icdf(FAE);
fpr=fnr;
plot(fpr, fnr,'color',[0 0 0]);

xtick = [0.0001, 0.0002, 0.0005, 0.001, 0.002, 0.005, 0.01, 0.02, 0.05, ...
         0.1, 0.2, 0.4];
xticklabel = num2str(xtick * 100, '%g\n');
xticklabel = textscan(xticklabel, '%s'); xticklabel = xticklabel{1};
set (gca, 'xtick', icdf(xtick));
set (gca, 'xticklabel', xticklabel);
xlim(icdf([0.00051 0.5]));
xlabel ('False Acceptance Rate (FAE) [%]');

ytick = xtick;         
yticklabel = num2str(ytick * 100, '%g\n');
yticklabel = textscan(yticklabel, '%s'); yticklabel = yticklabel{1};
set (gca, 'ytick', icdf(ytick));
set (gca, 'yticklabel', yticklabel);
ylim(icdf([0.00051 0.5]));
ylabel ('False Rejection Rate (FRE) [%]')

grid on;
box on;
axis square;
axis manual;

function y = icdf(x)
% computes the inverse of cumulative distribution function in x
y = -sqrt(2).*erfcinv(2 * ( x + eps));
y(isinf(y)) = nan;
