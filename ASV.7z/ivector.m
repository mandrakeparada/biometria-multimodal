function ivector(tipo,path,path3)

%{ 

This is a demo on how to use the Identity Toolbox for i-vector based speaker
recognition. A relatively small scale task has been designed using speech
material from the TIMIT corpus. There are a total of 630 (192 female and
438 male) speakers in TIMIT, from which we have selected 530 speakers for
background model training and the remaining 100 (30 female and 70 male)
speakers are used for tests. There are 10 short sentences per speaker in
TIMIT. For background model training we use all sentences from all 530
speakers (i.e., 5300 speech recordings in total). For speaker specific
model training we use 9 out of 10 sentences per speaker and keep the
remaining 1 sentence for tests. Verification trials consist of all possible
model-test combinations, making a total of 10,000 trials (100 target vs
9900 impostor trials).

Assuming that audio recordings are already converted 
into cepstral features, there are 5 steps involved:
 
 1. training a UBM from background data
 2. learning a total variability subspace from background statistics
 3. training a Gaussian PLDA model with development i-vectors
 4. scoring verification trials with model and test i-vectors
 5. computing the performance measures (e.g., EER)

Note: given the relatively small size of the task, we can load all the data 
and models into memory. This, however, may not be practical for large scale 
tasks (or on machines with a limited memory). In such cases, the parameters 
should be saved to the disk.

Omid Sadjadi <s.omid.sadjadi@gmail.com>
Microsoft Research, Conversational Systems Research Center

%}

% clc
% clear all
% close all

poolobj = gcp('nocreate');
delete(poolobj);
W_Dir = 'D';
% tipo = '_audio_noVAD';

%% Step0: Opening MATLAB pool
nworkers = 12;
nworkers = min(nworkers, feature('NumCores'));
%isopen = matlabpool('size')>0;
%if ~isopen, matlabpool(nworkers); end
isempty2 = isempty(gcp('nocreate'));
if ~isempty2, parpool(nworkers); end


%% Step1: Training the UBM
dataList = ['D:/doutorado/testes_dez/lists/datalist_',tipo,'.txt'];
file = [path,tipo,'/ubm_',tipo];
nmix = 128;
final_niter = 10;
ds_factor = 1;
ubm = gmm_em(dataList, nmix, final_niter, ds_factor, nworkers,file);
%% Step2: Learning the total variability subspace from background data
load ([path,tipo,'/ubm_',tipo])
ubm=gmm
tv_dim = 100; 
niter  = 10;
dataList = [path,'/lists/datalist_',tipo,'.txt'];
fid = fopen(dataList, 'rt');
C = textscan(fid, '%s');
fclose(fid);
feaFiles = C{1};
stats = cell(length(feaFiles), 1);
parfor file = 1 : length(feaFiles),
    [N, F] = compute_bw_stats(feaFiles{file}, ubm);
    stats{file} = [N; F];
end
T = train_tv_space(stats, ubm, tv_dim, niter, nworkers);

%% Step3: Training the Gaussian PLDA model with development i-vectors
lda_dim = 50;
nphi    = 200;
niter   = 10;
dataList = [path,'/lists/datalist_id_',tipo,'.txt'];
fid = fopen(dataList, 'rt');
C = textscan(fid, '%s %s');
fclose(fid);
feaFiles = C{1};
dev_ivs = zeros(tv_dim, length(feaFiles));
parfor file = 1 : length(feaFiles),
    dev_ivs(:, file) = extract_ivector(stats{file}, ubm, T);
end
% reduce the dimensionality with LDA
spk_labs = C{2};
V = lda(dev_ivs, spk_labs);
dev_ivs = V(:, 1 : lda_dim)' * dev_ivs;
%------------------------------------
plda = gplda_em(dev_ivs, spk_labs, nphi, niter);

%% Step4: Scoring the evaluation trials
fea_dir = [path3];
fea_ext = '.htk';
fid = fopen([path,'/lists/speaker_model_maps_',tipo,'.txt'], 'rt');
C = textscan(fid, '%s %s');
fclose(fid);
model_ids = unique(C{1}, 'stable');
model_files = C{2};
nspks = length(model_ids);
model_ivs1 = zeros(tv_dim, nspks);
model_ivs2 = model_ivs1;
parfor spk = 1 : nspks,
    ids = find(ismember(C{1}, model_ids{spk}));
    spk_files = model_files(ids);
    spk_files = cellfun(@(x) fullfile(fea_dir, [x, fea_ext]),...  %# Prepend path to files
                       spk_files, 'UniformOutput', false);
    N = 0; F = 0; 
    for ix = 1 : length(spk_files),
        [n, f] = compute_bw_stats(spk_files{ix}, ubm);
        N = N + n; F = f + F; 
        model_ivs1(:, spk) = model_ivs1(:, spk) + extract_ivector([n; f], ubm, T);
    end
    model_ivs2(:, spk) = extract_ivector([N; F]/length(spk_files), ubm, T); % stats averaging!
    model_ivs1(:, spk) = model_ivs1(:, spk)/length(spk_files); % i-vector averaging!
end
trial_list = [path,'/lists/evaluation_ptc_',tipo,'.txt'];
fid = fopen(trial_list, 'rt');
C = textscan(fid, '%s %s %s');
fclose(fid);
[model_ids, ~, Kmodel] = unique(C{1}, 'stable'); % check if the order is the same as above!
[test_files, ~, Ktest] = unique(C{2}, 'stable');
test_files = cellfun(@(x) fullfile(fea_dir, [x, fea_ext]),...  %# Prepend path to files
                       test_files, 'UniformOutput', false);
test_ivs = zeros(tv_dim, length(test_files));
parfor tst = 1 : length(test_files),
    [N, F] = compute_bw_stats(test_files{tst}, ubm);
    test_ivs(:, tst) = extract_ivector([N; F], ubm, T);
end
% reduce the dimensionality with LDA
model_ivs1 = V(:, 1 : lda_dim)' * model_ivs1;
model_ivs2 = V(:, 1 : lda_dim)' * model_ivs2;
test_ivs = V(:, 1 : lda_dim)' * test_ivs;
%------------------------------------
scores1 = score_gplda_trials(plda, model_ivs1, test_ivs);
linearInd =sub2ind([nspks, length(test_files)], Kmodel, Ktest);
scores1 = scores1(linearInd); % select the valid trials

scores2 = score_gplda_trials(plda, model_ivs2, test_ivs);
scores2 = scores2(linearInd); % select the valid trials

%% Step5: Computing the EER and plotting the DET curve
labels = C{3};
[thresh1,eer1,dcf08,dcf10] = compute_eer(scores1, labels, false , false); % IV averaging
hold on
[thresh2,eer2,dcf08b,dcf10b] = compute_eer(scores2, labels, false, false); % stats averaging
save([path,tipo,'/ivector_evaluation_',tipo,'.mat']);

%% Step6: Scoring the verification trials
fea_dir = [path3];
fea_ext = '.htk';
fid = fopen([path,'/lists/speaker_model_maps_',tipo,'.txt'], 'rt');
D = textscan(fid, '%s %s');
fclose(fid);
model_ids = unique(D{1}, 'stable');
model_files = D{2};
nspks = length(model_ids);
model_ivs1 = zeros(tv_dim, nspks);
model_ivs2 = model_ivs1;
parfor spk = 1 : nspks,
    ids = find(ismember(D{1}, model_ids{spk}));
    spk_files = model_files(ids);
    spk_files = cellfun(@(x) fullfile(fea_dir, [x, fea_ext]),...  %# Prepend path to files
                       spk_files, 'UniformOutput', false);
    N = 0; F = 0; 
    for ix = 1 : length(spk_files),
        [n, f] = compute_bw_stats(spk_files{ix}, ubm);
        N = N + n; F = f + F; 
        model_ivs1(:, spk) = model_ivs1(:, spk) + extract_ivector([n; f], ubm, T);
    end
    model_ivs2(:, spk) = extract_ivector([N; F]/length(spk_files), ubm, T); % stats averaging!
    model_ivs1(:, spk) = model_ivs1(:, spk)/length(spk_files); % i-vector averaging!
end
trial_list = [path,'/lists/test_',tipo,'.txt'];
fid = fopen(trial_list, 'rt');
D = textscan(fid, '%s %s %s');
fclose(fid);
[model_ids, ~, Kmodel] = unique(D{1}, 'stable'); % check if the order is the same as above!
[test_files, ~, Ktest] = unique(D{2}, 'stable');
test_files = cellfun(@(x) fullfile(fea_dir, [x, fea_ext]),...  %# Prepend path to files
                       test_files, 'UniformOutput', false);
test_ivs = zeros(tv_dim, length(test_files));
parfor tst = 1 : length(test_files),
    [N, F] = compute_bw_stats(test_files{tst}, ubm);
    test_ivs(:, tst) = extract_ivector([N; F], ubm, T);
end
% reduce the dimensionality with LDA
model_ivs1 = V(:, 1 : lda_dim)' * model_ivs1;
model_ivs2 = V(:, 1 : lda_dim)' * model_ivs2;
test_ivs = V(:, 1 : lda_dim)' * test_ivs;
%------------------------------------
scores3 = score_gplda_trials(plda, model_ivs1, test_ivs);
linearInd =sub2ind([nspks, length(test_files)], Kmodel, Ktest);
scores3 = scores3(linearInd); % select the valid trials

scores4 = score_gplda_trials(plda, model_ivs2, test_ivs);
scores4 = scores4(linearInd); % select the valid trials

%% step 6: Computando as m�tricas finais
%load gmm_results_test_p2_NO_VAD
labels2 = D{3};
[results,E] = compute_eer_p(scores3, labels2, thresh1,D);
[results2,E2] = compute_eer_p(scores4, labels2, thresh2,D);
[thresh3,eer3,dcf08c,dcf10c] = compute_eer(scores4, labels2, false, false);
save([path,tipo,'/ivector_results__tvdim100_',tipo,'.mat']);




