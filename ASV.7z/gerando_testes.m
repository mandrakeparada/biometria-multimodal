clear all 
close all
clc

%%create the test sequence file

struct_tests(1:151) = struct ('type',[],'VAD',0,'VVAD',0,'rz',0,'snr',0,'noise','b','select','x','ncoef',5,'delta',0);
snr=30;
for i=1:7
    struct_tests(i).type ='a';
    struct_tests(i).snr = snr;
    snr=snr-5;
end
snr=30;
for i=8:14
    struct_tests(i).type ='a';
    struct_tests(i).snr = snr;
    struct_tests(i).noise = 'w';
    snr=snr-5;
end
snr=30;
for i=15:21
    struct_tests(i).type ='a';
    struct_tests(i).snr = snr;
    struct_tests(i).VAD = 1;
    snr=snr-5;
end
snr=30;
for i=22:28
    struct_tests(i).type ='a';
    struct_tests(i).snr = snr;
    struct_tests(i).noise = 'w';
    struct_tests(i).VAD = 1;
    snr=snr-5;
end
snr=30;
for i=29:35
    struct_tests(i).type ='a';
    struct_tests(i).snr = snr;
    struct_tests(i).VVAD = 1;
    snr=snr-5;
end
snr=30;
for i=36:42
    struct_tests(i).type ='a';
    struct_tests(i).snr = snr;
    struct_tests(i).noise = 'w';
    struct_tests(i).VVAD = 1;
    snr=snr-5;
end

ncoef=[1 3 5 10 15 20 25 30 35 40 45 50 55 60];
k=1;
for i=43:56
    struct_tests(i).type ='v';
    struct_tests(i).select = 'x';
    struct_tests(i).VVAD = 0;
    struct_tests(i).ncoef = ncoef(k);
    k=k+1;
end
k=1;
for i=57:70
    struct_tests(i).type ='v';
    struct_tests(i).select = 'x';
    struct_tests(i).VVAD = 1;
    struct_tests(i).ncoef = ncoef(k);
    k=k+1;
end
k=2;
for i=71:83
    struct_tests(i).type ='v';
    struct_tests(i).select = 'y';
    struct_tests(i).VVAD = 0;
    struct_tests(i).ncoef = ncoef(k);
    k=k+1;
end
k=2;
for i=84:96
    struct_tests(i).type ='v';
    struct_tests(i).select = 'y';
    struct_tests(i).VVAD = 1;
    struct_tests(i).ncoef = ncoef(k);
    k=k+1;
end

ncoef=[1 3 5 10 15 20 25 30 35 40 45 50 55 60];
k=1;
for i=97:110
    struct_tests(i).type ='c';
    struct_tests(i).select = 'x';
    struct_tests(i).VVAD = 0;
    struct_tests(i).ncoef = ncoef(k);
    struct_tests(i).snr = 30;
    k=k+1;
end

ncoef=[1 3 5 10 15 20 25 30 35 40 45 50 55 60];
k=1;
for i=111:123
    struct_tests(i).type ='c';
    struct_tests(i).select = 'x';
    struct_tests(i).VVAD = 1;
    struct_tests(i).ncoef = ncoef(k);
    struct_tests(i).snr = 30;
    k=k+1;
end

snr=30;
for i=124:130
    struct_tests(i).type ='c';
    struct_tests(i).noise = 'w';
    struct_tests(i).select = 'x';
    struct_tests(i).VVAD = 0;
    struct_tests(i).ncoef = 15;
    struct_tests(i).snr = snr;
    snr=snr-5;
end

snr=30;
for i=131:137
    struct_tests(i).type ='c';
    struct_tests(i).noise = 'b';
    struct_tests(i).select = 'x';
    struct_tests(i).VVAD = 0;
    struct_tests(i).ncoef = 15;
    struct_tests(i).snr = snr;
    snr=snr-5;
end

snr=30;
for i=138:144
    struct_tests(i).type ='c';
    struct_tests(i).noise = 'w';
    struct_tests(i).select = 'x';
    struct_tests(i).VVAD = 1;
    struct_tests(i).ncoef = 15;
    struct_tests(i).snr = snr;
    snr=snr-5;
end

snr=30;
for i=145:151
    struct_tests(i).type ='c';
    struct_tests(i).noise = 'b';
    struct_tests(i).select = 'x';
    struct_tests(i).VVAD = 1;
    struct_tests(i).ncoef = 15;
    struct_tests(i).snr = snr;
    snr=snr-5;
end



save('testes','struct_tests')