function [dct_labiox2, dct_labioy2] = medium_motion_novo(speakers_in,session_in,phrase_in,path)

locutor = speakers_in(1,:);
sessao = session_in(1,:);
frase = phrase_in(1,:);
if (frase=='1'||frase=='4')
    resultados = [path,locutor,'\vector_',locutor,'_',sessao,'_',frase,'to',frase+1,'.mp4.mat'];
    videoFilename1 = [path,locutor,'\',locutor,'_',sessao,'_',frase,'to',frase+1,'.mp4'];
else
    resultados = [path,locutor,'\vector_',locutor,'_',sessao,'_',frase,'.mp4.mat'];
    videoFilename1 = [path,locutor,'\',locutor,'_',sessao,'_',frase,'.mp4'];
end
video = VideoReader(videoFilename1);
load (resultados);
num_quadro_atual=1;

%inicia as matrizes e vetores antes do loop.


while hasFrame(video)
    % Detecta as regi�es faciais
    quadro_atual=quadro(num_quadro_atual).frame;
    im=readFrame(video);
    if(pict_type(num_quadro_atual)=='I')
        [bbox_mouth,bbox_face] = region_detect(im,0);
    end
    if (size(quadro_atual,1)~=0)
        %computa as matrizes de movimento
        [matrizx,matrizy] = comput_mat2(quadro_atual,im);
        
        % estima as matrizes de movimento na regi�o
        labio_vetoresx = movment_mat(matrizx,bbox_mouth);
        labio_vetoresy = movment_mat(matrizy,bbox_mouth);
        
        dct_labiox = dct(dct(abs(labio_vetoresx))')';
        dct_labioxz = zigzag(dct_labiox);
        dct_labioxf(num_quadro_atual,:) = dct_labioxz(1:100);
        dct_labioy = dct(dct(abs(labio_vetoresy))')';
        dct_labioyz = zigzag(dct_labioy);
        dct_labioyf(num_quadro_atual,:) = dct_labioyz(1:100);
    end
    num_quadro_atual=num_quadro_atual+1;
end
dct_labioxf(frame,1:100)=0;
dct_labioyf(frame,1:100)=0;

%interpola��o
dct_labioy2 =zeros(size(dct_labioyf,1),100);
dct_labiox2 =zeros(size(dct_labioxf,1),100);
indy = find(dct_labioyf(2:end-1,1)==0);
indx = find(dct_labioxf(2:end-1,1)==0);
for i=1:size(indy)
    dct_labioy2 (indy(i)+1,:) = (dct_labioyf(indy(i),:)+dct_labioyf(indy(i)+2,:))/2;
end
for i=1:size(indx)
    dct_labiox2 (indx(i)+1,:) = (dct_labioxf(indx(i),:)+dct_labioxf(indx(i)+2,:))/2;
end
dct_labioy2 = dct_labioy2+dct_labioyf;
dct_labiox2 = dct_labiox2+dct_labioxf;


end
