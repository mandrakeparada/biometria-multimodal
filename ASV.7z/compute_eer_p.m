function [results,E] = compute_eer(scores, labels, thresh,D)
% results = [FA_FAE, FR_FAE, FA_FAE_FRE, FR_FAE_FRE, FA_FRE, FR_FRE, TER_FAE, TER_FAE_FRE, TER_FRE, VR];



if iscell(labels),
    labs = zeros(length(labels), 1);
    labs(ismember(labels, 'target')) = 1;
    labels = labs;
    clear labs;
end
E = ones(size(D{3},1),1);

%[scores2,I] = sort(scores);
%x = labels(I);

T_FAE = thresh(1);
T_FRE = thresh(2);
T_FAE_FRE = thresh(3);

I = sum (labels == 0);
C = sum (labels == 1);

total = I+C;

FA_FAE=0;
FR_FAE=0;
FA_FAE_FRE=0;
FR_FAE_FRE=0;
FA_FRE=0;
FR_FRE=0;

for i=1:length(labels)
    if (scores(i)>T_FAE && labels(i)==0)
        FA_FAE = FA_FAE + 1;
    end
    if (scores(i)<=T_FAE && labels(i)==1)
        FR_FAE = FR_FAE + 1;
    end
    if (scores(i)>T_FAE_FRE && labels(i)==0)
        FA_FAE_FRE = FA_FAE_FRE + 1;
        E(i,1)=0;
    end
    if (scores(i)<=T_FAE_FRE && labels(i)==1)
        FR_FAE_FRE = FR_FAE_FRE + 1;
        E(i,1)=0;
    end
     if (scores(i)>T_FRE && labels(i)==0)
        FA_FRE = FA_FRE + 1;
    end
    if (scores(i)<=T_FRE && labels(i)==1)
        FR_FRE = FR_FRE + 1;
    end
end
FA_FAE = FA_FAE*100/ I;
FR_FAE = FR_FAE*100/ C; 
FA_FAE_FRE = FA_FAE_FRE*100/ I;
FR_FAE_FRE = FR_FAE_FRE*100/ C; 
FA_FRE = FA_FRE*100/ I;
FR_FRE = FR_FRE*100/ C; 

TER_FAE = FA_FAE + FR_FAE;
TER_FAE_FRE = FA_FAE_FRE + FR_FAE_FRE;
TER_FRE = FA_FRE + FR_FRE;

VR = (100 - TER_FAE_FRE);

results = [FA_FAE, FR_FAE, FA_FAE_FRE, FR_FAE_FRE, FA_FRE, FR_FRE, TER_FAE, TER_FAE_FRE, TER_FRE, VR];

