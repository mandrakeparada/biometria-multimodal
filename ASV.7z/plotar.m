clear all
close all
clc
load (['D:\doutorado\testes_dez\resultados_final_dez_ivector_gmm64_t100\resultados.mat'])

%% audio

snr = 0:5:25;
vrb = [struct_tests(7).VR, struct_tests(6).VR, struct_tests(5).VR, struct_tests(4).VR, ...
    struct_tests(3).VR struct_tests(3).VR];
vrb_VAD = [struct_tests(21).VR struct_tests(20).VR struct_tests(19).VR struct_tests(18).VR, ...
    struct_tests(17).VR struct_tests(16).VR];
vrb_VVAD = [struct_tests(35).VR struct_tests(34).VR struct_tests(33).VR struct_tests(32).VR, ...
    struct_tests(31).VR struct_tests(30).VR];
plot(snr,vrb,'-o','color',[0 0 0])
hold on
% plot(snr,vrb_VAD,'-x','color',[1 0 0])
% hold on
plot(snr,vrb_VVAD,'-^','color',[0 0 1])
hold on
vrw = [struct_tests(14).VR, struct_tests(13).VR, struct_tests(12).VR, struct_tests(11).VR, ...
    struct_tests(10).VR struct_tests(9).VR]; 
vrw_VAD = [struct_tests(28).VR struct_tests(27).VR struct_tests(26).VR struct_tests(25).VR, ...
    struct_tests(24).VR struct_tests(23).VR];
vrw_VVAD = [struct_tests(42).VR struct_tests(41).VR struct_tests(40).VR struct_tests(39).VR, ...
    struct_tests(38).VR struct_tests(37).VR];
plot(snr,vrw,'-s','color',[1 0.5 0])
hold on
% plot(snr,vrw_VAD,'-*','color',[0.5 0.5 0.5])
% hold on
plot(snr,vrw_VVAD,'-d','color',[0 0.5 1])
%title('MFCC only')
xlabel ('SNR(dB)')
ylabel ('\itVR\rm(%)')
axis ([0 25 45 100]) 
legend({'Babble noise, VVAD = 0', ...
    'Babble noise, VVAD = 1', 'White noise, VVAD = 0',...
    'White noise, VVAD = 1'},'Location','East')
ax = gca;
ax.FontSize=16;
ax.FontName='TimesNewRoman';


%% Video
figure
ncoef = [3 5 10 15 20 25 30 35 40 45 50 55 ];
vry = [struct_tests(71).VR struct_tests(72).VR struct_tests(73).VR struct_tests(74).VR, ...
    struct_tests(75).VR struct_tests(76).VR struct_tests(77).VR struct_tests(78).VR , ...
    struct_tests(79).VR struct_tests(80).VR struct_tests(81).VR struct_tests(82).VR, ...
    ];
vry_VVAD = [struct_tests(84).VR struct_tests(85).VR struct_tests(86).VR struct_tests(87).VR, ...
    struct_tests(88).VR struct_tests(89).VR struct_tests(90).VR struct_tests(91).VR , ...
    struct_tests(92).VR struct_tests(93).VR struct_tests(94).VR struct_tests(95).VR, ...
    ];
vrx = [struct_tests(44).VR struct_tests(45).VR struct_tests(46).VR struct_tests(47).VR, ...
    struct_tests(48).VR struct_tests(49).VR struct_tests(50).VR struct_tests(51).VR , ...
    struct_tests(52).VR struct_tests(53).VR struct_tests(54).VR struct_tests(55).VR, ...
    ];
vrx_VVAD = [struct_tests(58).VR struct_tests(59).VR struct_tests(60).VR struct_tests(61).VR, ...
    struct_tests(62).VR struct_tests(63).VR struct_tests(64).VR struct_tests(65).VR , ...
    struct_tests(66).VR struct_tests(67).VR struct_tests(68).VR struct_tests(69).VR, ...
    ];
plot(ncoef,vry,'-o','color',[0 0 0])
hold on
plot(ncoef,vry_VVAD,'-x','color',[1 0 0])
hold on
plot(ncoef,vrx,'-*','color',[0 0 1])
hold on
plot(ncoef,vrx_VVAD,'-s','color',[0.5 0.5 0.5])
%title('Motion Features')
xlabel ('\it N')
ylabel ('\itVR\rm(%)')
axis ([0 55 60 100]) 
legend ({'Direction\it v, \rmVVAD=0','Direction\it v, \rmVVAD=1','Direction\it h \rmand\it v, \rmVVAD=0','Direction\it h \rmand\it v, \rmVVAD=1'},'Location','East') 
ax = gca;
ax.FontSize=16;
ax.FontName='TimesNewRoman';
%% audio + video

figure
snr = 0:5:25;
vrx = [struct_tests(137).VR, struct_tests(136).VR, struct_tests(135).VR, struct_tests(134).VR, ...
    struct_tests(133).VR struct_tests(132).VR]; 
vrx_VVAD = [struct_tests(151).VR, struct_tests(150).VR, struct_tests(149).VR, struct_tests(148).VR, ...
    struct_tests(147).VR struct_tests(146).VR];
plot(snr,vrx,'-o','color',[0 0 0])
hold on
plot(snr,vrx_VVAD,'-x','color',[1 0 0])
hold on
vrxw = [struct_tests(130).VR, struct_tests(129).VR, struct_tests(128).VR, struct_tests(127).VR, ...
    struct_tests(126).VR struct_tests(125).VR];
vrx_VVADw = [struct_tests(144).VR, struct_tests(143).VR, struct_tests(142).VR, struct_tests(141).VR, ...
    struct_tests(140).VR struct_tests(139).VR];
plot(snr,vrxw,'-*','color',[0 0 1])
hold on
plot(snr,vrx_VVADw,'-s','color',[0.5 0.5 0.5])
%title('MFCC + Motion (x and y)')
xlabel ('SNR(dB)')
ylabel ('\itVR\rm(%)')
axis ([0 25 80 100])
legend({'Babble noise, VVAD=0','Babble noise, VVAD=1','White noise, VVAD=0','White noise, VVAD=1'},'Location','East')
ax = gca;
ax.FontSize=16;
ax.FontName='TimesNewRoman';

%%audio+video
figure
ncoef = [1 3 5 10 15 20 25 30 35 40 45 50 55];
vrx = [struct_tests(97).VR struct_tests(98).VR struct_tests(99).VR struct_tests(100).VR, ...
    struct_tests(101).VR struct_tests(102).VR struct_tests(103).VR struct_tests(104).VR , ...
    struct_tests(105).VR struct_tests(106).VR struct_tests(107).VR struct_tests(108).VR, ...
    struct_tests(109).VR ];
vrx_VVAD = [struct_tests(111).VR struct_tests(112).VR struct_tests(113).VR struct_tests(114).VR, ...
    struct_tests(115).VR struct_tests(116).VR struct_tests(117).VR struct_tests(118).VR , ...
    struct_tests(119).VR struct_tests(120).VR struct_tests(121).VR struct_tests(122).VR, ...
    struct_tests(123).VR ];
plot(ncoef,vrx,'-o','color',[0 0 0])
hold on
plot(ncoef,vrx_VVAD,'-x','color',[1 0 0])
%title('MFCC + Motion (x + y) - No noise')
xlabel ('\it N')
ylabel ('\itVR\rm(%)')
axis ([0 55 80 100])
legend({'VVAD=0','VVAD=1'},'Location','East')
ax = gca;
ax.FontSize=16;
ax.FontName='TimesNewRoman';
%% audio
figure
snr = 0:5:25;
eer3b = [struct_tests(7).eer3, struct_tests(6).eer3, struct_tests(5).eer3, struct_tests(4).eer3, ...
    struct_tests(3).eer3 struct_tests(3).eer3];
eer3b_VAD = [struct_tests(21).eer3 struct_tests(20).eer3 struct_tests(19).eer3 struct_tests(18).eer3, ...
    struct_tests(17).eer3 struct_tests(16).eer3];
eer3b_VVAD = [struct_tests(35).eer3 struct_tests(34).eer3 struct_tests(33).eer3 struct_tests(32).eer3, ...
    struct_tests(31).eer3 struct_tests(30).eer3];
plot(snr,eer3b,'-o','color',[0 0 0])
hold on
% plot(snr,eer3b_VAD,'-x','color',[1 0 0])
% hold on
plot(snr,eer3b_VVAD,'-^','color',[0 0 1])
hold on
eer3w = [struct_tests(14).eer3, struct_tests(13).eer3, struct_tests(12).eer3, struct_tests(11).eer3, ...
    struct_tests(10).eer3 struct_tests(9).eer3]; %modificado para aprecer no plot
eer3w_VAD = [struct_tests(28).eer3 struct_tests(27).eer3 struct_tests(26).eer3 struct_tests(25).eer3, ...
    struct_tests(24).eer3 struct_tests(23).eer3];
eer3w_VVAD = [struct_tests(42).eer3 struct_tests(41).eer3 struct_tests(40).eer3 struct_tests(39).eer3, ...
    struct_tests(38).eer3 struct_tests(37).eer3];
plot(snr,eer3w,'-s','color',[1 0.5 0])
hold on
% plot(snr,eer3w_VAD,'-*','color',[0.5 0.5 0.5])
% hold on
plot(snr,eer3w_VVAD,'-d','color',[0 0.5 1])
%title('MFCC only')
xlabel ('SNR(dB)')
ylabel ('\itEER_{T}\rm(%)')
axis ([0 25 0 25]) 
legend({'Babble noise, VVAD = 0', ...
    'Babble noise, VVAD = 1', 'White noise, VVAD = 0',...
    'White noise, VVAD = 1'},'Location','East')
ax = gca;
ax.FontSize=16;
ax.FontName='TimesNewRoman';

%% Video
figure
ncoef = [3 5 10 15 20 25 30 35 40 45 50 55 ];
eer3y = [struct_tests(71).eer3 struct_tests(72).eer3 struct_tests(73).eer3 struct_tests(74).eer3, ...
    struct_tests(75).eer3 struct_tests(76).eer3 struct_tests(77).eer3 struct_tests(78).eer3 , ...
    struct_tests(79).eer3 struct_tests(80).eer3 struct_tests(81).eer3 struct_tests(82).eer3, ...
    ];
eer3y_VVAD = [struct_tests(84).eer3 struct_tests(85).eer3 struct_tests(86).eer3 struct_tests(87).eer3, ...
    struct_tests(88).eer3 struct_tests(89).eer3 struct_tests(90).eer3 struct_tests(91).eer3 , ...
    struct_tests(92).eer3 struct_tests(93).eer3 struct_tests(94).eer3 struct_tests(95).eer3, ...
    ];
eer3x = [struct_tests(44).eer3 struct_tests(45).eer3 struct_tests(46).eer3 struct_tests(47).eer3, ...
    struct_tests(48).eer3 struct_tests(49).eer3 struct_tests(50).eer3 struct_tests(51).eer3 , ...
    struct_tests(52).eer3 struct_tests(53).eer3 struct_tests(54).eer3 struct_tests(55).eer3, ...
    ];
eer3x_VVAD = [struct_tests(58).eer3 struct_tests(59).eer3 struct_tests(60).eer3 struct_tests(61).eer3, ...
    struct_tests(62).eer3 struct_tests(63).eer3 struct_tests(64).eer3 struct_tests(65).eer3 , ...
    struct_tests(66).eer3 struct_tests(67).eer3 struct_tests(68).eer3 struct_tests(69).eer3, ...
    ];
plot(ncoef,eer3y,'-o','color',[0 0 0])
hold on
plot(ncoef,eer3y_VVAD,'-x','color',[1 0 0])
hold on
plot(ncoef,eer3x,'-*','color',[0 0 1])
hold on
plot(ncoef,eer3x_VVAD,'-s','color',[0.5 0.5 0.5])
%title('Motion Features')
xlabel ('\it N')
ylabel ('\itEER_{T}\rm(%)')
axis ([0 55 0 15]) 
legend ({'Direction\it v, \rmVVAD=0','Direction\it v, \rmVVAD=1','Direction\it h \rmand\it v, \rmVVAD=0','Direction\it h \rmand\it v, \rmVVAD=1'},'Location','East') 
ax = gca;
ax.FontSize=16;
ax.FontName='TimesNewRoman';
%% audio + video

figure
snr = 0:5:25;
eer3x = [struct_tests(137).eer3, struct_tests(136).eer3, struct_tests(135).eer3, struct_tests(134).eer3, ...
    struct_tests(133).eer3 struct_tests(132).eer3]; %SNR =20 modificado
eer3x_VVAD = [struct_tests(151).eer3, struct_tests(150).eer3, struct_tests(149).eer3, struct_tests(148).eer3, ...
    struct_tests(147).eer3 struct_tests(146).eer3];
plot(snr,eer3x,'-o','color',[0 0 0])
hold on
plot(snr,eer3x_VVAD,'-x','color',[1 0 0])
hold on
eer3xw = [struct_tests(130).eer3, struct_tests(129).eer3, struct_tests(128).eer3, struct_tests(127).eer3, ...
    struct_tests(126).eer3 struct_tests(125).eer3];
eer3x_VVADw = [struct_tests(144).eer3, struct_tests(143).eer3, struct_tests(142).eer3, struct_tests(141).eer3, ...
    struct_tests(140).eer3 struct_tests(139).eer3];
plot(snr,eer3xw,'-*','color',[0 0 1])
hold on
plot(snr,eer3x_VVADw,'-s','color',[0.5 0.5 0.5])
%title('MFCC + Motion (x and y)')
xlabel ('SNR(dB)')
ylabel ('\itEER_{T}\rm(%)')
axis ([0 25 0 7])
legend({'Babble noise, VVAD=0','Babble noise, VVAD=1','White noise, VVAD=0','White noise, VVAD=1'},'Location','East')
ax = gca;
ax.FontSize=16;
ax.FontName='TimesNewRoman';

%%
figure
ncoef = [1 3 5 10 15 20 25 30 35 40 45 50 55];
eer3x = [struct_tests(97).eer3 struct_tests(98).eer3 struct_tests(99).eer3 struct_tests(100).eer3, ...
    struct_tests(101).eer3 struct_tests(102).eer3 struct_tests(103).eer3 struct_tests(104).eer3 , ...
    struct_tests(105).eer3 struct_tests(106).eer3 struct_tests(107).eer3 struct_tests(108).eer3, ...
    struct_tests(109).eer3 ];
eer3x_VVAD = [struct_tests(111).eer3 struct_tests(112).eer3 struct_tests(113).eer3 struct_tests(114).eer3, ...
    struct_tests(115).eer3 struct_tests(116).eer3 struct_tests(117).eer3 struct_tests(118).eer3 , ...
    struct_tests(119).eer3 struct_tests(120).eer3 struct_tests(121).eer3 struct_tests(122).eer3, ...
    struct_tests(123).eer3 ];
plot(ncoef,eer3x,'-o','color',[0 0 0])
hold on
plot(ncoef,eer3x_VVAD,'-x','color',[1 0 0])
%title('MFCC + Motion (x + y) - No noise')
xlabel ('\it N')
ylabel ('\itEER_{T}\rm(%)')
axis ([0 55 0 1])
legend({'VVAD=0','VVAD=1'},'Location','East')
ax = gca;
ax.FontSize=16;
ax.FontName='TimesNewRoman';