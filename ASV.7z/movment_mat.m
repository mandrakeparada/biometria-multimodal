function output_matrix = movment_mat(matriz,bbox)
%Input: 
%   matriz: matrix of motion
%   bbox: bbox of region detection
%Output:
%   output_matrix

    output_matrix = matriz(bbox(1,2):(bbox(1,4)+bbox(1,2)), bbox(1,1):(bbox(1,3)+bbox(1,1)),:);
    %imagem = im(bbox(1,2):(bbox(1,4)+bbox(1,2)), bbox(1,1):(bbox(1,3)+bbox(1,1)));
end