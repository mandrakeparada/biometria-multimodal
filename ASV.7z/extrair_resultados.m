%% setup do teste
clear all
close all
clc

load testes.mat

path = 'D:/doutorado/testes_dez/resultados_19_01_gmm_256';
for i =1:151
% type a(audio), v(video), c(audio+video)
type = struct_tests(i).type;

% For audio type only selects the Voice Activity detection. 
% VAD = 0 (no VAD) VAD=1 (with VAD)
VAD = struct_tests(i).VAD;

% For video or audio +video selects the Visual VAD. 
% VVAD = 0 (no VVAD) VVAD=1 (with VVAD)
VVAD = struct_tests(i).VVAD;

%For video type selects the zero removal
rz=struct_tests(i).rz;

% For audio type selects the SNR (30 = no noise)
snr = struct_tests(i).snr;

% para tipo �udio seleciona o tipo do ru�do
noise = struct_tests(i).noise;

% For video type select = y (only y matrix) select =x (matrices x e y)
select = struct_tests(i).select;

% For video type selects the number of coefficients. If select ='x' the
% number of coefficients is equal to double ncoef.
ncoef = struct_tests(i).ncoef;

delta=struct_tests(i).delta;

if type =='a'
    tipo = ['a','_VAD_',num2str(VAD),'_VVAD_',num2str(VVAD),'_SNR_',num2str(snr),'_ruido_',noise,'_matriz_','-','_coef_','-'];
end

if type =='v'
    tipo = ['v','_VAD_','-','_VVAD_',num2str(VVAD),'_SNR_','-','_ruido_','-','_matriz_',select,'_coef_',num2str(ncoef),'_rz_',num2str(rz),'_delta_',num2str(delta)];
end

if type =='c'
    tipo  = ['av','_VAD_','-','_VVAD_',num2str(VVAD),'_SNR_',num2str(snr),'_ruido_',noise,'_matriz_',select,'_coef_',num2str(ncoef),'_rz_',num2str(rz),'_delta_',num2str(delta)];
    tipoa = ['a','_VAD_',num2str(VAD),'_VVAD_',num2str(VVAD),'_SNR_',num2str(snr),'_ruido_',noise,'_matriz_','-','_coef_','-'];
    tipov = ['v','_VAD_','-','_VVAD_',num2str(VVAD),'_SNR_','-','_ruido_','-','_matriz_',select,'_coef_',num2str(ncoef),'_rz_',num2str(rz),'_delta_',num2str(delta)];
end

load([path,'/',tipo,'/gmm_results__',tipo])
struct_tests(i).eer1=eer;
struct_tests(i).eer3=eer3;
struct_tests(i).VR=results(end);
end

save ([path,'/resultados'],'struct_tests')
            