function feature_matrix= htk_write(tipo,final_vector,snr2,VAD,VVAD,noise,path,path2)
% vetor_mfcc= htk_write(tipo,final_vector,snr2,VAD,VVAD,,path,path2)
% write the htk feature files.
% Inputs:
%   tipo: string vector with the test type
%   final_vector: feature vectors in case of video or audio +video
%                 in case of audio only the input must be zero.
%   snr2: the final desired audio SNR
%   VAD: Selects VAD (0 or 1)
%   VVAD: Selects VVAD (0 or 1)
%   noise: type of noise ('w'= white, 'b'=babble)
%   path: database path
%   path2: feature path
%Outputs:
%   feature_matrix: returns the final feature matrix

fs = 32000; %sample frequency XM2VTSdb
fstep = 0.040; % step window (40ms)
ftam = 0.050; % window size (50ms)

%configuration MFCC
fL = 100.0/fs; %low frequency filter
fH = 8000.0/fs; %figh frequency filter
fRate = fstep * fs; %number of samples corresponding to the step 
fSize = ftam * fs;%number of samples in the window 
nChan = 27;
nCeps = 12;% number of cepstrals coefficients

todos=['000';'001';'002';'003';'004';'005';'006';'007';'008';'009';'010';'011';'012';'013';'016';'017';'018';'019';'020';'021';'022';
    '023';'024';'025';'026';'027';'028';'029';'030';'031';'032';'033';'034';'035';'036';'037';'038';'039';'040';'041';'042';'043';'044';
    '045';'046';'047';'048';'049';'050';'051';'052';'053';'054';'055';'056';'057';'058';'059';'060';'061';'062';'064';'065';'066';'067';
    '068';'069';'070';'071';'072';'073';'074';'075';'078';'079';'080';'081';'082';'083';'085';'086';'087';'088';'089';'090';'091';'092';
    '093';'095';'096';'098';'099';'101';'102';'103';'104';'105';'107';'108';'109';'110';'111';'112';'113';'114';'115';'116';'119';'120';
    '121';'122';'123';'124';'125';'126';'127';'128';'129';'130';'131';'132';'133';'134';'135';'136';'137';'138';'140';'141';'142';'143';
    '145';'146';'147';'148';'149';'150';'152';'153';'154';'155';'157';'158';'159';'160';'161';'163';'164';'165';'166';'167';'168';'169';
    '170';'171';'172';'173';'174';'175';'176';'177';'178';'179';'180';'181';'182';'183';'185';'187';'188';'189';'190';'191';'193';'196';
    '197';'198';'199';'200';'201';'202';'203';'206';'207';'208';'209';'210';'211';'212';'213';'215';'216';'218';'219';'221';'222';'224';
    '225';'226';'227';'228';'229';'231';'232';'233';'234';'235';'236';'237';'240';'241';'242';'243';'244';'246';'248';'249';'250';'253';
    '255';'258';'259';'261';'263';'264';'266';'267';'269';'270';'271';'272';'274';'275';'276';'278';'279';'280';'281';'282';'283';'284';
    '285';'286';'287';'288';'289';'290';'292';'293';'295';'300';'301';'305';'310';'312';'314';'315';'316';'317';'318';'319';'320';'321';
    '322';'323';'324';'325';'328';'329';'330';'331';'332';'333';'334';'335';'336';'337';'338';'339';'340';'341';'342';'357';'358';'359';
    '360';'362';'364';'365';'366';'367';'369';'370';'371'];

%% video htk

if (tipo(1) =='v' || (tipo(1) =='a'&&tipo(2)=='v'))
    %     load('vetorfinal_zigzag')
    nfrases = size(final_vector,2);
    for i=1:nfrases
        file = [path2,final_vector(i).speaker,'\',final_vector(i).speaker,'_',...
            final_vector(i).session,'_',final_vector(i).phrase,'to',final_vector(i).phrase+1,'_',tipo,'.htk'];
        writehtk(file,final_vector(i).value,1/25,9);
    end
end

%% audio htk
if (tipo(1)=='a'&&tipo(2)~='v')
        aux = 1;
    for pers_i=1:(size(todos,1)) %for each speaker
        person=todos(pers_i,:);
        if VVAD ==1
        load ([path,person,'\movimento_dct_',person,'.mat']);
        end
        aux2=1;
        for k=1:4 % for sessions 1 to 4
            session=num2str(k);
            for j=1:3:4 %for each phrase
                phrase=num2str(j);
                wavFilename1 = [path,person,'\',person,'_',session,'_',phrase,'to',phrase+1,'.mp4'];
                filehtk=[path2,person,'\',person,'_',session,'_',phrase,'to',phrase+1,'_',tipo,'.htk'];
                [audio1, fs] = audioread(wavFilename1);
                audio1 = audio1(:,1);
                if (snr2~=30) %snr2 =30 is equal to no noise
                    if (noise=='w') %white noise
                        rng('default')
                        n = randn(10000000,1);
                    end
                    if (noise=='b') %bubble noise
                        n=audioread('babble.wav');
                    end
                    tam = size(audio1,1); %audio size
                    n = n(1:tam); %cut the noise to the audio size
                    es = audio1'*audio1; %signal energy
                    en = n'*n; %noise energy
                    R = 10^(snr(audio1,n)/10); %linear snr
                    u= sqrt(10^(snr2/10)/R); % adjuste SNR
                    nf = n/u; %adjusted noise
                    audio2 = audio1 + nf; %compute the noisy signal
                else
                    audio2 =audio1;
                end
                %Voice Activity detector (VAD) from Voicebox. Cut the Audio during silence
                if (VAD ==1)
                    [vs,z0]=vadsohn(audio2,fs);
                    j=1;
                    af1=[];
                    for i=1:size(vs,1)
                        if(vs(i)==1)
                            af1(j,1)= audio2(i);
                            j=j+1;
                        end
                    end
                else
                    af1 = audio2;
                end
                %extracts the cepstral coefficients
                mfc1 = melcepst(af1, fs, '0dD', nCeps, nChan, fSize, fRate, fL, fH);%compute MFCC coefficients
                mfc1 = cmvn(mfc1', true);
                mfc1 = mfc1';
                if VVAD==1
                    ind = struct_motion_dct(aux2).movimento;
                    mfc1=mfc1(ind,:);
                end
                feature_matrix(aux) = struct('value',mfc1,'speaker',person,...
                    'session',session,'phrase',phrase); %store the features on a struct
                writehtk(filehtk, mfc1, 1/25, 9); %write htk files
                aux = aux+1;
                aux2 = aux2+1;
            end
        end
    end
end
end
