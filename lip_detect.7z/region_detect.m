function [bbox_mouth,bbox_face] = region_detect (videoFrame,draw)
%Detect the regions
%[bbox_mouth,bbox_mouth_sup,bbox_mouth_inf,bbox_face] = region_detect (videoFrame,draw)
%Inputs: 
%   VideoFrame: Image
%   draw: 0 or 1 to select the graphics 
%Output: Detected Boxes
%   bbox_mouth : [initial_column,initial_line,width,heigth]
%   bbox_face : [initial_column,initial_line,width,heigth]


%% Detect the regions
% Create a cascade detector object.
FaceDetector = vision.CascadeObjectDetector('FrontalFaceCart');
MouthDetector = vision.CascadeObjectDetector('Mouth');
MouthDetector.MinSize = [60 60];
FaceDetector.MinSize = [150 100];
MouthDetector.MergeThreshold = 120;
%MouthDetector.UseROI =1;
%FaceDetector.MergeThreshold = 20;

%convert to gray image
videoFrame      = rgb2gray(videoFrame);
bbox_face       = step(FaceDetector, videoFrame);
bbox_face(1,4)=bbox_face(1,4)+20;
if (size(bbox_face,1)>1)
    bbox_face = bbox_face(1,:);
end
%if no box is detect
if (size(bbox_face,1)==0)
    bbox_face(1) = 200;
    bbox_face(2) = 200;
    bbox_face(3) = 300;
    bbox_face(4) = 300;
end
%bottom half of face. ROI for lip detection
videoFrame2_mi   = videoFrame(bbox_face(1,2)+ceil(bbox_face(1,4)/2):(bbox_face(1,4)+bbox_face(1,2)), bbox_face(1,1):(bbox_face(1,3)+bbox_face(1,1)));
%Lip detection
bbox_mouth       = step(MouthDetector, videoFrame2_mi);
% if no lip is detected
if (size(bbox_mouth,1)==0)
    bbox_mouth(1)=ceil(bbox_face(1)+1/4*bbox_face(3));
    bbox_mouth(3)=ceil(bbox_face(3)/2);
    bbox_mouth(2)=ceil((bbox_face(2)+bbox_face(4))-(bbox_face(4)/4));
    bbox_mouth(4)=ceil(bbox_face(2)+bbox_face(4)-bbox_mouth(2));
else
    bbox_mouth(1)    = bbox_face(1,1)+bbox_mouth(1,1);
    bbox_mouth(2)    = bbox_face(2)+bbox_mouth(2)+ceil(bbox_face(1,4)/2);
    bbox_mouth(4)    = bbox_face(2)+bbox_face(4) - bbox_mouth(2);
end


% Draw the returned bounding box around the detected face.
if (draw ==1)
    videoOut = insertObjectAnnotation(videoFrame,'rectangle',bbox_face,'Face','LineWidth',3,'FontSize',32);
    videoOut2 = insertObjectAnnotation(videoOut,'rectangle',bbox_mouth,'Mouth','LineWidth',3,'FontSize',32);  
    figure
    imshow(videoOut2)
end

end