function mask = lip_detect(speaker_in,session_in,phrase_in,path,method)
% bbox_labio = labio_detect(speaker_in,session_in,phrase_in)
% Inputs:
%   speaker_in: speaker to detect the lip region. e.g. ['000']
%   session_in: selected sesssion . e.g.['1']
%   phrase_in: selected phrase . e.g. ['1'] or ['3'] or ['4']
%              phrases 1 and 4 corresponds to uttered digits 
%              phrase 3 correspond to "Joe took fathers green show bench
%              out"
%   path: selects the path of the database . e.g.'D:/database'
%   method: selects the method for segmentation ('kmeans' , 'gaussian',
%           'thresold')
%
% Output:
%   mask: returns the binary mask to be applied to image for lip
%         segmentation

%%% IMPORTANT %%% PATH
speaker = speaker_in(1,:);
session = session_in(1,1);
phrase = phrase_in(1,:);
if (phrase=='1'||phrase=='4')
    resultados = [path,speaker,'\vector_',speaker,'_',session,'_',phrase,'to',phrase+1,'.mp4.mat'];
    videoFilename1 = [path,speaker,'\',speaker,'_',session,'_',phrase,'to',phrase+1,'.mp4'];
    
else
    resultados = [path,speaker,'\vector_',speaker,'_',session,'_',phrase,'.mp4.mat'];
    videoFilename1 = [path,speaker,'\',speaker,'_',session,'_',phrase,'.mp4'];
end
video = VideoReader(videoFilename1);

%load the result from mpegflow
load (resultados);

num_quadro_atual=1;
num_quadro2=1;
i=1;
%for each frame of the video
while hasFrame(video)
    quadro_atual=quadro(num_quadro_atual).frame;
    im=readFrame(video);
       
    %detect the facial region for each Intra frame
    if(pict_type(num_quadro_atual)=='I')
        [~,bbox_face] = region_detect(im,0); %%
    end
    if (size(quadro_atual,1)~=0)
        [H(:,:,num_quadro_atual),V(:,:,num_quadro_atual)]= comput_mat2(quadro_atual,im);
    end
    if (rem(num_quadro_atual,50)==0)
        %compute the module matriz
        D = sqrt(H(:,:,num_quadro2:num_quadro_atual-1).^2 +V(:,:,num_quadro2:num_quadro_atual-1).^2);
        D=D(bbox_face(1,2):bbox_face(1,2)+bbox_face(1,4),bbox_face(1,1):bbox_face(1,1)+bbox_face(1,3),:);
        %im2=im1(bbox_face(1,2):bbox_face(1,2)+bbox_face(1,4),bbox_face(1,1):bbox_face(1,1)+bbox_face(1,3),:);
        im3=im(bbox_face(1,2):bbox_face(1,2)+bbox_face(1,4),bbox_face(1,1):bbox_face(1,1)+bbox_face(1,3),:);
        
        %plota a imagem do rosto
        subplot(5,3,i)
        imshow (im3)
        title('Imagem da face')
        i=i+1;
        
        %Gaussian filter
        X = sum(D,3);
        R= imgaussfilt(X,10);
        
        %Gaussiana - EM
        if (strcmp(method,'gaussian'))
        [mask,mu,v,p]=EMSeg(R,2);
        mask(mask==1)=0;
        mask(mask==2)=1;
        subplot(5,3,i)
        imshow (mask)
        title('Segmenta��o Gaussiana')
        i=i+1;
        end
        
        %Threshold
        if (strcmp(method,'threshold'))
        T = mean(mean(R)+1.5*std(std(R)));
        mask=R;
        mask(mask<=T)=0;
        mask(mask~=0)=1;
        subplot(5,3,i)
        imshow(mask)
        title('Segmenta��o com limiar de intensidade')
        i=i+1;
        end
        
        %K-means
        if (strcmp(method,'kmeans'))
        numberOfClasses=2;
        indexes = kmeans(R(:),numberOfClasses);
        mask = reshape(indexes, size(R));
        mask(mask==1)=0;
        mask(mask==2)=1;
        subplot(5,3,i)
        imshow(mask)
        title('Segmenta��o com k-means')
        i=i+1;
        end
        
        % plota a imagem do l�bio
        subplot(5,3,i)
        im4 = rgb2gray(im3).*uint8(mask);
        imshow(im4)
        title('Regi�o Labial')
        i=i+1;
        num_quadro2= num_quadro_atual;
    end
    num_quadro_atual=num_quadro_atual+1;
end
end