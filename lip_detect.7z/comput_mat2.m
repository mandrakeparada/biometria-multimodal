function [H,V] = comput_mat2 (quadro_atual,im)
%computes the horixontal and vertical movement matrix
% Input : (matrix M from mpegflow, image)
% output: [ horizontal matrix, vertical matrix]

latual =8;
lanterior=0;

for i=2:size(quadro_atual,1)-1
    if(quadro_atual(i,2)==quadro_atual(i-1,2))
        H(lanterior+1:latual,quadro_atual(i-1,1):quadro_atual(i,1))=quadro_atual(i-1,3);
    else
       % matriz_y(lanterior+1:latual,quadro_atual(i-1,1):size(im,2))=quadro_atual(i,4);
        lanterior=latual;
        latual = quadro_atual(i,2);
        H(lanterior+1:latual,1:quadro_atual(i,1))=quadro_atual(i,3);
    end
end

H(size(H,1):size(im,1),:)=0;
H(:,size(H,2):size(im,2))=0;
H = H(1:size(im,1),1:size(im,2));

% matriz com os vetores em y
for i=2:size(quadro_atual,1)-1
    if(quadro_atual(i,2)==quadro_atual(i-1,2))
        V(lanterior+1:latual,quadro_atual(i-1,1):quadro_atual(i,1))=quadro_atual(i-1,4);
    else
       % matriz_y(lanterior+1:latual,quadro_atual(i-1,1):size(im,2))=quadro_atual(i,4);
        lanterior=latual;
        latual = quadro_atual(i,2);
        V(lanterior+1:latual,1:quadro_atual(i,1))=quadro_atual(i,4);
    end
end

V(size(V,1):size(im,1),:)=0;
V(:,size(V,2):size(im,2))=0;
V = V(1:size(im,1),1:size(im,2));
    
% for i=2:size(quadro_atual,1)-1
%     if(quadro_atual(i,2)==quadro_atual(i-1,2))
%         matriz_modulo(lanterior+1:latual,quadro_atual(i-1,1):quadro_atual(i,1))=sqrt(quadro_atual(i,3)^2+quadro_atual(i,4)^2);
%     else
%        % matriz_y(lanterior+1:latual,quadro_atual(i-1,1):size(im,2))=quadro_atual(i,4);
%         lanterior=latual;
%         latual = quadro_atual(i,2);
%         matriz_modulo(lanterior+1:latual,1:quadro_atual(i,1))=sqrt(quadro_atual(i,3)^2+quadro_atual(i,4)^2);
%     end
% end
% 
% matriz_modulo(size(matriz_modulo,1):size(im,1),:)=0;
% matriz_modulo(:,size(matriz_modulo,2):size(im,2))=0;
% matriz_modulo = matriz_modulo(1:size(im,1),1:size(im,2));
end

