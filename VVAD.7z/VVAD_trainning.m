function [thresholdh,thresholdv] = VVAD_trainning(speakers_in,session_in,phrase_in,path,k)
%inputs:
%   speakers_in: list of speakers in the trainning phase.
%   Example: speakers_in = ['000';'001'];
%   session_in: list of session in the trainning phase.
%   Example: session_in = ['1';'2'];
%   phrase_in: list of phrases in the trainning phase.
%   Example: session_in = ['1';'3']; %phrases must be 1 and/or 3 and/or 4
%   according to the name of the files in XM2VTSdb
%   path: path of the database
%   k: value of k that adjusts the thresholds.

%Outputs:
%   thresholdx: Values of threshold of motion in the horizontal direction
%   thresholdy: Values of threshold of motion in the vertical direction

person = 1;
vaux=1;

while(person<=size(speakers_in,1))
    session = 1;
    speaker = speakers_in(person,:);
    while(session<=size(session_in,1))
        phrase = 1;
        sessao = session_in(session,1);
        while(phrase<=size(phrase_in,1))
            frase = phrase_in(phrase,:);
            if (frase=='1'||frase=='4')
                %file that stores the results from mpegflow
                results = [path,speaker,'\vector_',speaker,'_',sessao,'_',frase,'to',frase+1,'.mp4.mat'];
                videoFilename1 = [path,speaker,'\',speaker,'_',sessao,'_',frase,'to',frase+1,'.mp4'];
                
            else
                %file that stores the results from mpegflow
                results = [path,speaker,'\vector_',speaker,'_',sessao,'_',frase,'.mp4.mat'];
                videoFilename1 = [path,speaker,'\',speaker,'_',sessao,'_',frase,'.mp4'];
            end
            %creates the video objet
            video = VideoReader(videoFilename1);
            %open the file that stores the results from mpegflow
            load (results);
            
            num_quadro_atual=1;
            
            %For each frame of the video
            while hasFrame(video)
                M=quadro(num_quadro_atual).frame;
                im=readFrame(video);
                
                %if Intra frame
                if(pict_type(num_quadro_atual)=='I')
                    % Detects the facial and lip regions
                    [bbox_mouth,bbox_face] = region_detect(im,0); %%
                end
                
                if (size(M,1)~=0)
                    %comput the motion matrices in the horizontal and
                    %verical directions
                    [H(:,:,num_quadro_atual),V(:,:,num_quadro_atual)]= comput_mat2(M,im);
                    
                    %Lip matrices
                    Lh = movment_mat(H(:,:,num_quadro_atual),bbox_mouth);
                    Lv = movment_mat(V(:,:,num_quadro_atual),bbox_mouth);
                    
                    %face matrices
                    Fh = movment_mat(H(:,:,num_quadro_atual),bbox_face);
                    Fv = movment_mat(V(:,:,num_quadro_atual),bbox_face);
                    
                    %Mean of motion in the facial region
                    ah = mean(mean(Fh));
                    av = mean(mean(Fv));
                    
                    %Motion compensation
                    Lh = Lh - ah;
                    Lv = Lv - av;
                    
                    %absolute of motion
                    ch(num_quadro_atual) = sum(sum(abs(Lh)))/(sqrt(size(Lh,1)*size(Lh,2)));%/(size(labio_imagemy,1)*size(labio_imagemy,2));
                    cv(num_quadro_atual) = sum(sum(abs(Lv)))/(sqrt(size(Lv,1)*size(Lv,2)));
                    
                end
                num_quadro_atual=num_quadro_atual+1;
            end
            
            %Interpolate the motion when zero motion is found
            abs_soma_labiov2 =zeros(1,length(cv));
            abs_soma_labioh2 =zeros(1,length(ch));
            indv = find(cv(2:end-1)==0);
            indh = find(ch(2:end-1)==0);
            for i=1:length(indv)
                abs_soma_labiov2 (indv(i)+1) = (cv(indv(i))+cv(indv(i)+2))/2;
            end
            for i=1:length(indh)
                abs_soma_labioh2 (indh(i)+1) = (ch(indh(i))+ch(indh(i)+2))/2;
            end
            cv = abs_soma_labiov2+cv;
            ch = abs_soma_labioh2+ch;
            
            %% audio VAD
            [audio1, fs] = audioread(videoFilename1);
            vad = VAD(audio1,fs);
            tam_audio = 1/fs*(size(audio1,1)); % tamanho do �udio em s
            window = 200E-3; % janela de tempo, s
            Z=2; %quadros ap�s a janela
            N = length(vad);
            
            %stores the lip open and closure of the lips
            open = [];
            close = [];
            for i = 1:N-1
                if (vad(i)==0 && vad(i+1) ==1)
                    open = [open, i];
                end
                if (vad(i)==1 && vad(i+1) ==0)
                    close = [close, i];
                end
            end
            
            fps=video.FrameRate;
            open = floor((open/length(vad))*tam_audio*fps); %frame number that lip opens
            close = floor((close/length(vad))*tam_audio*fps); %frame number that lip closures
            W = floor((window/tam_audio)*frame);%frame size fo motion estimation
            
            %%
            mean_openh = zeros(1,length(open));
            mean_openv = zeros(1,length(open));
            %calcula a media do movimento quando ocorre uma aberura de labio
            for i = 1:length(open)
                if(open(i)-W<=0)
                    mean_openh(i) = mean(ch(1:(open(i)+Z)));
                    mean_openv(i) = mean(cv(1:(open(i)+Z)));
                end
                if((open(i)+Z)>length(cv))
                    mean_openh(i) = mean(ch((open(i)-W):length(ch)));
                    mean_openv(i) = mean(cv((open(i)-W):length(cv)));
                end
                if(open(i)-W>0&&(open(i)+Z)<=length(cv))
                    mean_openh(i) = mean(ch((open(i)-W):(open(i)+Z)));
                    mean_openv(i) = mean(cv((open(i)-W):(open(i)+Z)));
                end
            end
            mean_openh = mean(mean_openh);
            mean_openv = mean(mean_openv);
            
            mean_closeh = zeros(1,length(close));
            mean_closev = zeros(1,length(close));
            %calcula a media do movimento quando ocorre um fechamento de labio
            for i = 1:length(close)
                if(close(i)-W<=0)
                    mean_closeh(i) = mean(ch(1:(close(i)+Z)));
                    mean_closev(i) = mean(cv(1:(close(i)+Z)));
                end
                if((close(i)+Z)>length(cv))
                    mean_closeh(i) = mean(ch((close(i)-W):length(ch)));
                    mean_closev(i) = mean(cv((close(i)-W):length(cv)));
                end
                if(close(i)-W>0&&(close(i)+Z)<=length(cv))
                    mean_closeh(i) = mean(ch((close(i)-W):(close(i)+Z)));
                    mean_closev(i) = mean(cv((close(i)-W):(close(i)+Z)));
                end
            end
            mean_closeh = mean(mean_closeh);
            mean_closev = mean(mean_closev);
            mean_speakerh (vaux) = mean([mean_openh mean_closeh]);
            mean_speakerv (vaux) = mean([mean_openv mean_closev]);
            vaux = vaux+1;
            
            clear('abs_soma_labiox')
            clear('abs_soma_labioy')
            phrase = phrase + 1;
        end
        session = session+1;
    end
    speaker_globalh = mean (mean_speakerh);
    std_dh = std(mean_speakerh);
    thresholdh = speaker_globalh-k*std_dh;
    
    speaker_globalv = mean (mean_speakerv);
    std_dv = std(mean_speakerv);
    thresholdv = speaker_globalv-k*std_dv;
    person = person+1;
end
end
