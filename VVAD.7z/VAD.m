function [vad,J,sum_E]= VAD (audio1,fs)
%Input: 
%   audio1: audio vector (mono)
%   fs: sampled frequency
%Output:
%   vad: ones and zeros vector (vad indications)


audio1=audio1(:,1);
window = 1/25;
N = floor(window * fs);
D = floor(N);
ind = 1:N;
J = floor((length(audio1) - N)/ D) + 1;
E = zeros(J,1);
Z = zeros(J,1);
vad = zeros(J,1);

% zero crossing
for i = 1:J,
    W = audio1(ind);
    W=W(:);
    E(i) = W'*W;
    W=W-mean(W);
    Z(i) = sum(abs(sign(W(2:end))-sign(W(1:end-1)))/2)/(N-1);
    ind = ind + D;
end

%energy
sum_E = 0;
maxE = max(E);
limiar = 0.1;
limE = limiar*maxE;
for i = 1:J
    if (E(i) > limE),
        vad(i) = 1;
        sum_E = sum_E+E(i);
    end
end

%audiowrite('audio.wav',audio1,fs)

end
