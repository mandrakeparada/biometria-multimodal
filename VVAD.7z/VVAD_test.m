function movimento_labial = VVAD_test(speakers_in,session_in,phrase_in,thresholdx,thresholdy,snr,path)

speaker = speakers_in(1,:);
session = session_in(1,1);
phrase = phrase_in(1,:);
if (phrase=='1'||phrase=='4')
    resultados = [path,speaker,'\vector_',speaker,'_',session,'_',phrase,'to',phrase+1,'.mp4.mat'];
    videoFilename1 = [path,speaker,'\',speaker,'_',session,'_',phrase,'to',phrase+1,'.mp4'];
    
else
    resultados = [path,speaker,'\vector_',speaker,'_',session,'_',phrase,'.mp4.mat'];
    videoFilename1 = [path,speaker,'\',speaker,'_',session,'_',phrase,'.mp4'];
end
[audio1, fs] = audioread(videoFilename1);
video = VideoReader(videoFilename1);
load (resultados);

num_quadro_atual=1;

%for each frame of the video
while (hasFrame(video))
    quadro_atual=quadro(num_quadro_atual).frame;
    im=readFrame(video);
    titulo = ['locutor',speaker]; %titulo para PLOT
    if(pict_type(num_quadro_atual)=='I')
        %Detect the regions
        [bbox_mouth,bbox_face] = region_detect(im,0); %%
    end
    if (size(quadro_atual,1)~=0)
        [H(:,:,num_quadro_atual),V(:,:,num_quadro_atual)]= comput_mat2(quadro_atual,im);
        
        % Lip matrices
        Lh = movment_mat(H(:,:,num_quadro_atual),bbox_mouth);
        Lv = movment_mat(V(:,:,num_quadro_atual),bbox_mouth);
        
        %face matrices
        Fh = movment_mat(H(:,:,num_quadro_atual),bbox_face);
        Fv = movment_mat(V(:,:,num_quadro_atual),bbox_face);
                    
                    %calcula a m�dia do movimento na regi�o da face
                    ah = mean(mean(Fh));
                    av = mean(mean(Fv));
                    
                    %Motion compensation
                    Lh = Lh - ah;
                    Lv = Lv - av;
                    
                    %absolute of motion
                    ch(num_quadro_atual) = sum(sum(abs(Lh)))/(sqrt(size(Lh,1)*size(Lh,2)));%/(size(labio_imagemy,1)*size(labio_imagemy,2));
                    cv(num_quadro_atual) = sum(sum(abs(Lv)))/(sqrt(size(Lv,1)*size(Lv,2)));
                
    end
    num_quadro_atual=num_quadro_atual+1;
end


% Interpolation of zero motion
abs_soma_labiov2 =zeros(1,length(cv));
abs_soma_labioh2 =zeros(1,length(ch));
indv = find(cv(2:end-1)==0);
indh = find(ch(2:end-1)==0);
for i=1:length(indv)
    abs_soma_labiov2 (indv(i)+1) = (cv(indv(i))+cv(indv(i)+2))/2;
end
for i=1:length(indh)
    abs_soma_labioh2 (indh(i)+1) = (ch(indh(i))+ch(indh(i)+2))/2;
end
cv = abs_soma_labiov2+cv;
ch = abs_soma_labioh2+ch;


%% VAD
n = randn(10000000,1);
tam = size(audio1,1);
audio1 = audio1(:,1);
if snr==30
    audion=audio1;
else
    %add the noise
    n = n(1:tam); 
    es = audio1'*audio1; 
    en = n'*n; 
    R = es/en; 
    v = sqrt((10^(snr/10))/R);
    nsnr = n/v;
    audion = audio1 + nsnr(1:tam);
end
[vad,J,sum_E] = VAD(audion,fs);
t = 0:1/fs:1/fs*(size(audio1,1)-1);
ta = 0:t(end)/(J-1):t(end);
figure
subplot(5,1,1)
plot(t,audion)
grid on
axis tight
xlabel({'t(s)'},'FontSize',14,'FontName','TimesNewRoman')
ylabel({'A(V)'},'FontSize',14,'FontName','TimesNewRoman')
title({titulo},'FontSize',16,'FontName','TimesNewRoman')
subplot(5,1,2)
plot(ta,vad,'LineWidth',2)
grid on
axis tight
xlabel({'t(s)'},'FontSize',14,'FontName','TimesNewRoman')
ylabel({'VAD'},'FontSize',14,'FontName','TimesNewRoman')
ylim([-0.1 1.1])
%legend ({'energy VAD','zero crossing'},'FontSize',10);

% Voice activity detection
movimento_labial=((ch>thresholdx) + (cv>thresholdy))>0;
fps=25;
movimento_labial(frame)=0;

%VVAD filter
movimento_media = tsmovavg(double(movimento_labial),'s',3,2);
move(find(movimento_media>1/3)-1)=1;
move(frame)=0;

tframe = linspace(0,ta(end),frame);
subplot(5,1,3)
plot(tframe,movimento_labial,'LineWidth',2)
grid on
axis tight
xlabel({'t(s)'},'FontSize',14,'FontName','TimesNewRoman')
ylabel({'VVAD'},'FontSize',14,'FontName','TimesNewRoman')
ylim([-0.1 1.1])
subplot(5,1,4)
plot(tframe,move,'LineWidth',2)
grid on
axis tight
xlabel({'t(s)'},'FontSize',14,'FontName','TimesNewRoman')
ylabel({'VVAD Filtrado'},'FontSize',14,'FontName','TimesNewRoman')
ylim([-0.1 1.1])

end